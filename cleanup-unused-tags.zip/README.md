# cleanup-unused-tags

Simple plugin that deletes unused tags (tags with 0 posts) upon activation

NOTE:  THIS PLUGIN WILL LIKELY CRASH THE SITE UPON COMPLETION.  SIMPLY DELETE THE FOLDER TO RECTIFY

To use: 

Upload and activate plugin

Deactivate plugin.
